#include <bits/stdc++.h>
#include <vector>
#include "Coordenada.h"
#include "PoligonoIrreg.h"

int main(){
	PoligonoIrreg p;
	p.anadeVertice(20, 10);
	p.anadeVertice(-5, -5);
	p.sumaVertices(2);
	vector<PoligonoIrreg> ans;
	for(int i = 0; i<1000;i++){
		PoligonoIrreg p;
		int vertices = rand()%1000;
		//cout<<vertices<<" "<<p.getVertices()<<endl;
		p.sumaVertices(vertices);
		for(int j = 0; j<vertices; j++){
			int x = rand()%100;
			int y = rand()%100;
			p.anadeVertice(x,y);
		}
		ans.push_back(p);
	}
	cout<<p.getVertices()<<endl;
	return 0;
}
