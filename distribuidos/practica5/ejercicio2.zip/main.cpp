#include <iostream>
#include <vector>
#include "Coordenada.h"
#include "PoligonoIrreg.h"

int main(){
	PoligonoIrreg p;
	p.anadeVertice(20, 10);
	p.imprimeVertices();
	p.anadeVertice(-5, -5);
	p.imprimeVertices();
	return 0;
}
