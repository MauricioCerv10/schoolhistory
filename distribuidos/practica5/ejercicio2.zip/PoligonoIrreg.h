
#include "Coordenada.h" 
#include <vector>
using namespace std;
#ifndef POLIGONOIRREG_H_
#define POLIGONOIRREG_H_


class PoligonoIrreg{
	private: 
			vector<Coordenada> vertices; 
	public: 
			PoligonoIrreg();
			void anadeVertice(double x, double y);
			void imprimeVertices(); 
};

#endif 
