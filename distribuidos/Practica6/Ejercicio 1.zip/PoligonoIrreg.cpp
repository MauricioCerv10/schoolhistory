#include "PoligonoIrreg.h"
#include "Coordenada.h"
#include <vector>
#include <math.h>
#include <iostream>
using namespace std;

//PoligonoIrreg::PoligonoIrreg(Coordenada c1, Coordenada c2, Coordenada c3){
//	vertices.push_back(c1);
//	vertices.push_back(c2);
//	vertices.push_back(c3);
//}

PoligonoIrreg::PoligonoIrreg(){
}

void PoligonoIrreg::imprimeVertices(){
	float pitagorazo;
	for(int i = 0; i < vertices.size(); i++){
		cout << "=============" << endl;
		cout << "Vértice " << i+1 << ": " << endl;
		cout << "  X: " << vertices[i].obtenerX() << endl;
		cout << "  Y: " << vertices[i].obtenerY() << endl;
		cout << "==" << endl;
		pitagorazo = sqrt(
				(vertices[i].obtenerX()*vertices[i].obtenerX()) +
				(vertices[i].obtenerY()*vertices[i].obtenerY())
			     );
		cout << "Magnitud: " << pitagorazo << endl;
		cout << "=============" << endl << endl;
	}
	return;
}

void PoligonoIrreg::anadeVertice(float x, float y){
	vertices.push_back(Coordenada(x, y));
	return;
}
