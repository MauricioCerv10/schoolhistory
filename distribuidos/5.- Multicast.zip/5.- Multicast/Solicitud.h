#ifndef SOLICITUD_H_
#define SOLICITUD_H_
#include "SocketMulticast.h"
#include "Mensaje.h"
#include <string.h>

class Solicitud{
	public:
		~Solicitud();
		Solicitud();
		char* doOperation(char *IP, int puerto, char* solicitud);
		char* getIP();
	private:
		SocketMulticast *socketLocal;
		struct mensaje Enviar;
		char* dirIP;
		char request;
};

#endif