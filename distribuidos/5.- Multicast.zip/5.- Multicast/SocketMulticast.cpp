#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netdb.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "SocketMulticast.h"
#include "PaqueteDatagrama.h"

using namespace std;

SocketMulticast::SocketMulticast(int a){
	s = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);

	if(s < 0){
		cout << "--!!ERROR FATAL: Error al llamar a la función socket." << endl;
		exit(0);
	}

	if(a == 0){ /*Es emisor*/
		unsigned char TTL = 1;
		if(setsockopt(s, IPPROTO_IP, IP_MULTICAST_TTL, (void *) &TTL, sizeof(TTL)) < 0){
			cout << "--!!ERROR FATAL: Error al llamar a la función setsockopt." << endl;
			exit(0);
		}
	}
	else{ /*Es receptor*/
		int reuse = 1;
		if (setsockopt(s, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse)) == -1) {
			cout << "--!!ERROR FATAL: Error al llamar a la función setsockopt." << endl;
			exit(0);
		}
	}

	grupoMulticast.sin_family = AF_INET;
	grupoMulticast.sin_port = htons(a);
	grupoMulticast.sin_addr.s_addr = inet_addr("224.0.0.1");
	if(a != 0) /*Es receptor*/ bind(s, (struct sockaddr*)&grupoMulticast, sizeof(grupoMulticast));

	multicast.imr_multiaddr.s_addr = grupoMulticast.sin_addr.s_addr;
	multicast.imr_interface.s_addr = htonl(INADDR_ANY);

	aa = a;
}

SocketMulticast::~SocketMulticast(){
	close(s);
}

int SocketMulticast::recibe(PaqueteDatagrama &p){
	char dat[p.obtieneLongitud()];
	unsigned int clileng = sizeof(grupoMulticast);
	recvfrom(s, dat, p.obtieneLongitud()*sizeof(char), 0, (struct sockaddr *) &grupoMulticast, &clileng);
	p.inicializaDatos(dat);
	char str[16];
	inet_ntop(AF_INET, &grupoMulticast.sin_addr.s_addr, str, 16);
	p.inicializaIp(str);
	p.inicializaPuerto(grupoMulticast.sin_port);
	return 0;
}

int SocketMulticast::envia(PaqueteDatagrama &p, unsigned char ttl){
	inet_pton(AF_INET, p.obtieneDireccion(), &grupoMulticast.sin_addr);
	grupoMulticast.sin_port = htons(p.obtienePuerto());
	sendto(s, p.obtieneDatos(), p.obtieneLongitud() * sizeof(char), 0, (struct sockaddr *) &grupoMulticast, sizeof(grupoMulticast));
	return 0;
}

void SocketMulticast::unirseGrupo(char * dir){
	multicast.imr_multiaddr.s_addr = inet_addr(dir);
	setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP, (void *) &multicast, sizeof(multicast));
}

void SocketMulticast::salirseGrupo(char * dir){
	multicast.imr_multiaddr.s_addr = inet_addr(dir);
	setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP, (void *) &multicast, sizeof(multicast));
}

//char* SocketMulticast::getClientIP(){return inet_ntoa(multicast.imr_multiaddr.s_addr);}
//unsigned short SocketMulticast::getClientPort(){return multicast.imr_interface.s_addr;}
