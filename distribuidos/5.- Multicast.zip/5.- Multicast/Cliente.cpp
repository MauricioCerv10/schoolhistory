#include <iostream>
#include "Solicitud.h"

using namespace std;

int main(int argc, char* argv[]){
	if(argc != 3){
		cout << "Mala invocación del programa. Intente:" << endl;
		cout << "./cliente direccion_multicast puerto" << endl;
		return 0;
	}
	srand(time(NULL));
	Solicitud s;
	struct mensaje mensajeEnvio;
	mensajeEnvio.argumentos = 'A';
	for(;;){
		cout << "========================================" << endl;
		cout << "Quiero enviar: " << mensajeEnvio.argumentos << endl;
		memcpy((char*)(&mensajeEnvio), s.doOperation(argv[1], atoi(argv[2]), (char*)(&mensajeEnvio)), sizeof(struct mensaje));
		cout << "Mensaje enviado dentro de Cliente.cpp." << endl;
		cout << "Tipo de mensaje: " << mensajeEnvio.messageType << endl;
		//cout << "ID: " << atoi(&mensajeEnvio.requestId) << endl;
		cout << "Argumentos: " << mensajeEnvio.argumentos << endl;
		sleep(3);
	}

	return 0;
}