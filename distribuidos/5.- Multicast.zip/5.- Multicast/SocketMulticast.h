#ifndef SOCKETMULTICAST_H_
#define SOCKETMULTICAST_H_
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <strings.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
#include "PaqueteDatagrama.h"

class SocketMulticast{
	private:
		struct sockaddr_in grupoMulticast;
		struct ip_mreq multicast;
		int s; //ID socket
		int aa;

	public:
		SocketMulticast(int a);
		~SocketMulticast();
		int recibe(PaqueteDatagrama &p);
		int envia(PaqueteDatagrama &p, unsigned char ttl);
		//Se une a un grupo multicast, recibe la IP multicast
		void unirseGrupo(char * dir);
		//Se sale de un grupo multicast, recibe la IP multicast
		void salirseGrupo(char * dir);
		char* getClientIP();
		unsigned short getClientPort();
};

#endif