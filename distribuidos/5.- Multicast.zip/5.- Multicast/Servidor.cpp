#include <iostream>
#include "Respuesta.h"

using namespace std;

int main(void){
	Respuesta r(7200);
	struct mensaje mensajeRecibo;

	while(1){
		cout << "Esperando mensaje..." << endl;
		memcpy(&mensajeRecibo, r.getRequest(), sizeof(struct mensaje));
		if(mensajeRecibo.messageType != '2'){
			cout << "==================================" << endl;
			cout << "Mensaje recibido dentro de Servidor.cpp." << endl;
			cout << "Tipo de mensaje: " << mensajeRecibo.messageType << endl;
			//cout << "ID: " << atoi(&mensajeRecibo.requestId) << endl;
			cout << "Argumentos recibidos: " << mensajeRecibo.argumentos << endl;
		}
	}
	return 0;
}