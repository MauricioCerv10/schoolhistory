#include <iostream>
#include "Solicitud.h"
#include "PaqueteDatagrama.h"
#include "SocketMulticast.h"

using namespace std;

Solicitud::Solicitud(){
	socketLocal = new SocketMulticast(0);
	request = 0;
}

char* Solicitud::doOperation(char *IP, int puerto, char* solicitud){
	memcpy((char*)&Enviar, solicitud, sizeof(struct mensaje));
	Enviar.messageType = '0';
	request++;
	Enviar.requestId = request;
	PaqueteDatagrama paqueteEnvio((char*)&Enviar, sizeof(struct mensaje), IP, puerto);

	socketLocal->envia(paqueteEnvio, 1);

	return (char*)&Enviar;
}

Solicitud::~Solicitud(){delete socketLocal;}

char* Solicitud::getIP(){return dirIP;}
