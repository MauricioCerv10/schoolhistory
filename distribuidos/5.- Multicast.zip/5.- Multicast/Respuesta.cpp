#include <iostream>
#include "Respuesta.h"
#include "PaqueteDatagrama.h"

using namespace std;

Respuesta::Respuesta(int pl){
	socketLocal = new SocketMulticast(pl);
	multicastIP = "224.0.0.1";
	socketLocal->unirseGrupo(multicastIP);
	requestIdPrev = -1;
}

struct mensaje* Respuesta::getRequest(void){
	PaqueteDatagrama paqueteRecibo(sizeof(struct mensaje));
	socketLocal->recibe(paqueteRecibo);
	memcpy((char*)&Recibido, paqueteRecibo.obtieneDatos(), sizeof(struct mensaje));
	requestIdPrev = Recibido.requestId;
	return &Recibido;
}

void Respuesta::sendReply(char *respuesta){
	return;
}

Respuesta::~Respuesta(){socketLocal->salirseGrupo(multicastIP);delete socketLocal;}

//char* Respuesta::getIP(){return dirIP;}
//int Respuesta::getPort(){return port;}