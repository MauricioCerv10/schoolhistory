// Definicion del formato de mensaje
struct mensaje{
	char messageType; //0= Solicitud, 1 = Respuesta
	char requestId; //Identificador del mensaje
	char argumentos;
};