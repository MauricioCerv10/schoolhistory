#include <iostream>
#include "PaqueteDatagrama.h"
#include "SocketMulticast.h"
#include <string.h>
#include "Mensaje.h"


using namespace std;

int main(void){
	SocketMulticast socketLocal(7200);
        socketLocal.unirseGrupo("224.0.0.1");
	int a; cin>>a;
	struct mensaje mensajeRecibo;
	struct mensaje mensajeEnvio;
	while(1){
		cout << "Esperando mensaje..." << endl;
		PaqueteDatagrama paqueteRecibo(sizeof(struct mensaje));
        	socketLocal.recibe(paqueteRecibo);
        	cout<<"Direccion: "<<paqueteRecibo.obtieneDireccion()<<endl;
        	cout<<"Puerto : "<<paqueteRecibo.obtienePuerto()<<endl;
		memcpy((char*)&mensajeRecibo, paqueteRecibo.obtieneDatos(), sizeof(struct mensaje));

		if(mensajeRecibo.messageType != '2'){
			cout << "==================================" << endl;
			cout << "Mensaje recibido dentro de Servidor.cpp." << endl;
			cout << "Tipo de mensaje: " << mensajeRecibo.messageType << endl;
			//cout << "ID: " << atoi(&mensajeRecibo.requestId) << endl;
			int res = mensajeRecibo.argumentos[0] + mensajeRecibo.argumentos[1] + a;
			cout << "Suma: " << res << endl;
			memcpy((char*)&mensajeEnvio, (char*)&mensajeRecibo, sizeof(struct mensaje));
			mensajeEnvio.argumentos[0] = res;
			PaqueteDatagrama pEnvia((char*)&mensajeEnvio, sizeof(struct mensaje) ,paqueteRecibo.obtieneDireccion(),
						7201);
			sleep(1);
			socketLocal.enviaU(pEnvia);
			/*SocketDatagrama sU(7201);
			sU.envia(pEnvia); */
		}
	}
	return 0;
}
