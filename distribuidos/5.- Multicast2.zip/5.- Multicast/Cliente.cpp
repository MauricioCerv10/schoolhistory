#include <iostream>
#include "PaqueteDatagrama.h"
#include "SocketMulticast.h"
#include "Mensaje.h"
#include <string.h>

using namespace std;

int main(int argc, char* argv[]){
	if(argc != 3){
		cout << "Mala invocación del programa. Intente:" << endl;
		cout << "./cliente direccion_multicast puerto" << endl;
		return 0;
	}
	srand(time(NULL));
	SocketMulticast socketLocal(0);
	/*SocketDatagrama sU(7201);*/
	struct mensaje mensajeEnvio;
	struct mensaje mensajeRecibo;
	mensajeEnvio.argumentos[0] = 4;
	mensajeEnvio.argumentos[1] = 7;
	for(;;){
		cout << "========================================" << endl;
		cout << "Quiero enviar:	 " << mensajeEnvio.argumentos[0] << " " << mensajeEnvio.argumentos[1] << endl;
		PaqueteDatagrama paqueteEnvio((char*)&mensajeEnvio, sizeof(struct mensaje), argv[1], atoi(argv[2]));
        	socketLocal.envia(paqueteEnvio, 1);
		cout << "Mensaje enviado dentro de Cliente.cpp." << endl;
		cout << "Tipo de mensaje: " << mensajeEnvio.messageType << endl;
		//cout << "ID: " << atoi(&mensajeEnvio.requestId) << endl;
		cout << "Argumentos: " << (int)mensajeEnvio.argumentos[0] << " " << (int)mensajeEnvio.argumentos[1] << endl;
		PaqueteDatagrama paqueteRecibo(sizeof(struct mensaje));
		socketLocal.recibeU(paqueteRecibo);
		memcpy((char*)&mensajeRecibo, paqueteRecibo.obtieneDatos(), sizeof(struct mensaje));
		cout<<"Recibí mensaje de IP :"<<paqueteRecibo.obtieneDireccion() << endl;
		cout<<"Desde el puerto : "<<paqueteRecibo.obtienePuerto()<<endl;
		cout<<"Recibí resultado: " << mensajeRecibo.argumentos[0] <<endl;
		sleep(3);
	}

	return 0;
}
